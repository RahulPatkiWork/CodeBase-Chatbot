cd CodeBaseGA/codelabs-nodejs/level3/functions/
firebase use --project codebase-8b5de
firebase deploy --project codebase-8b5de
